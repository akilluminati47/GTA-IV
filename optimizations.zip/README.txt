To install just copy the contents of the optimizations folder into your GTA 4 directory ex. C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto IV 

REPLACE ALL FILES WITH THESE FOR PATCH

Improves performance and allows more settings to be used

This can be used on a vanilla install of the complete edition